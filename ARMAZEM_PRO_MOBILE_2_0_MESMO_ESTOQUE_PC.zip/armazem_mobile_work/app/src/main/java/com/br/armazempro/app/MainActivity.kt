package com.br.armazempro.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.br.armazempro.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = fileChooserCallback ?: return@registerForActivityResult
            callback.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
            fileChooserCallback = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(binding.webView, true)

        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            textZoom = 100
            userAgentString = "$userAgentString ArmazemProAndroid/2.0"
        }

        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                return if (isInternalUrl(uri)) {
                    false
                } else {
                    openExternalUrl(uri)
                    true
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                binding.swipeRefresh.isRefreshing = false
                binding.offlineView.isVisible = false
                binding.webView.isVisible = true
                binding.syncStatus.text = getString(R.string.sincronizado)
                injectMobileEnhancements(view)
                super.onPageFinished(view, url)
            }
        }

        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.isVisible = newProgress in 1..99
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams?.createIntent())
                    true
                } catch (_: ActivityNotFoundException) {
                    fileChooserCallback = null
                    false
                }
            }
        }

        binding.webView.setDownloadListener(
            DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                try {
                    val request = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mimeType)
                        .addRequestHeader("User-Agent", userAgent)
                        .addRequestHeader(
                            "Cookie",
                            CookieManager.getInstance().getCookie(url)
                        )
                        .setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                        )
                        .setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS,
                            android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
                        )
                    getSystemService(DownloadManager::class.java).enqueue(request)
                } catch (_: Exception) {
                    openExternalUrl(Uri.parse(url))
                }
            }
        )

        binding.swipeRefresh.setOnRefreshListener { reload() }
        binding.retryButton.setOnClickListener { loadApp() }
        binding.refreshButton.setOnClickListener { reload() }
        binding.homeButton.setOnClickListener { binding.webView.loadUrl(BuildConfig.APP_URL) }
        binding.backButton.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack() else binding.webView.loadUrl(BuildConfig.APP_URL)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(R.string.sair_app)
                        .setMessage(R.string.deseja_sair)
                        .setNegativeButton(R.string.cancelar, null)
                        .setPositiveButton(R.string.sair) { _, _ -> finish() }
                        .show()
                }
            }
        })

        loadApp()
    }

    private fun injectMobileEnhancements(webView: WebView) {
        val script = """
            (function() {
              var meta = document.querySelector('meta[name=viewport]');
              if (!meta) {
                meta = document.createElement('meta');
                meta.name = 'viewport';
                document.head.appendChild(meta);
              }
              meta.content = 'width=device-width, initial-scale=1, viewport-fit=cover';

              if (!document.getElementById('armazem-pro-mobile-css')) {
                var style = document.createElement('style');
                style.id = 'armazem-pro-mobile-css';
                style.innerHTML = `
                  html, body { max-width: 100vw !important; overflow-x: hidden !important; }
                  input, select, textarea, button { font-size: 16px !important; }
                  img, svg, canvas { max-width: 100%; }
                  table { display: block; width: 100%; max-width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; }
                  .modal, [role=dialog] { max-width: calc(100vw - 20px) !important; }
                  @media (max-width: 720px) {
                    main, .container, .content, .page, .dashboard { max-width: 100% !important; min-width: 0 !important; }
                    .row { flex-wrap: wrap !important; }
                    input, select, textarea { max-width: 100% !important; }
                  }
                `;
                document.head.appendChild(style);
              }
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private fun loadApp() {
        if (hasInternet()) {
            binding.offlineView.isVisible = false
            binding.webView.isVisible = true
            binding.syncStatus.text = getString(R.string.sincronizado)
            binding.webView.loadUrl(BuildConfig.APP_URL)
        } else {
            showOffline()
        }
    }

    private fun reload() {
        if (hasInternet()) {
            binding.syncStatus.text = getString(R.string.sincronizado)
            binding.webView.reload()
        } else {
            binding.swipeRefresh.isRefreshing = false
            showOffline()
        }
    }

    private fun showOffline() {
        binding.webView.isVisible = false
        binding.offlineView.isVisible = true
        binding.syncStatus.text = getString(R.string.sem_sincronizacao)
    }

    private fun hasInternet(): Boolean {
        val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun isInternalUrl(uri: Uri): Boolean {
        val host = uri.host?.lowercase().orEmpty()
        return host == "armazempro.com.br" ||
            host.endsWith(".armazempro.com.br") ||
            host.endsWith(".supabase.co") ||
            host == "api.mercadopago.com" ||
            host.endsWith(".mercadopago.com.br")
    }

    private fun openExternalUrl(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    override fun onDestroy() {
        binding.webView.apply {
            stopLoading()
            clearHistory()
            removeAllViews()
            destroy()
        }
        super.onDestroy()
    }
}
